name="Fred"


def display_details():
    age = 21
    print("Name:", name)
    print("Age:", age)


#Part 1 : Print name

#Part 2: Print age?

#Part 3: Call display_details

