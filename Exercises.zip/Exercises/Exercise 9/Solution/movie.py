class Movie:
    def __init__(self):   
        self.title = "Jaws"
        self.director = "Steven Spielberg"
        self.year = 1975

    def display_details(self):
        print("Title:", self.title)
        print("Director:", self.director)
        print("Year:", self.year)

