movies = [{"title": "Jaws", "director": "Steven Spielberg", "year": 1975, "duration": 124.0},
          {"title": "Star Wars","director": "George Lucas", "year": 1977, "duration": 91.0}]
print("Title:" + movies[1]["title"])
print("Year:" + str(movies[1]["year"]))
print("Director:" + movies[1]["director"])
