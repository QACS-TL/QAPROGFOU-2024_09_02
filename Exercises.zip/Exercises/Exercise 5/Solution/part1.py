topFive = ["Star Wars", "Jaws", "Postman Pat 2", "Vanilla Sky", "Absolutely Fabulous"]
print(topFive)
topFive.append("One Flew over the Cuckoos nest")
print(topFive)
print(len(topFive))
topFive[len(topFive)-1] = "It's a beautiful life"
print(topFive)
