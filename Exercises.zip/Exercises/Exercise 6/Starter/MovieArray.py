movies = ["Jaws","Star Wars", "Vanilla Sky", "The Mission", "Bridget Jones Diary 2"]
print(movies)
new_movie = input("Enter Movie Title to Add:")

# Check if movie exists if it doesn't then append to array, otherwise say it exists
