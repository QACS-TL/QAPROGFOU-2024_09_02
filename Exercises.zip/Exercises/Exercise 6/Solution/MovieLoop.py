movies = ["Jaws", "Star Wars", "Vanilla Sky", "The Mission", "Bridget Jones Diary 2"]

# Iterate through each movie and print out
for movieTitle in movies:
    print(movieTitle)

