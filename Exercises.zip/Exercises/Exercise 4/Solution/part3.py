speed = 47
time = 2.5
distance = 47 * 2.5
print("Distance travelled {0}".format(distance))
print(f"Distance travelled {distance}")  # print statements do the same thing!
