count = 0
count += 5
count *= 2
print(count, type(count))
count *= 1.0
print(count, type(count))
