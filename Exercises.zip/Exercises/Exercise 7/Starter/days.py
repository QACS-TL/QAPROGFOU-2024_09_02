day = "mon"
cap_day = day.capitalize()
full_day = cap_day + "day"
print(full_day)
