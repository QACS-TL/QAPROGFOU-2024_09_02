def expand_day(day):

    cap_day = day.capitalize()

    full_day = cap_day + "day"

    return full_day


print(expand_day("sun"))
